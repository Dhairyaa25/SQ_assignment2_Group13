﻿using System;


namespace CarRentalReservationSystem
{

    public enum CustomerType
    {
        Regular = 0,
        Premium = 1,
        VIP = 2
    }

    public enum CarType
    {
        Economy = 0,
        Standard = 1,
        Luxury = 2
    }  
    class Program
    {

        static List<Reservation> reservations = new List<Reservation>();

        static void Main(string[] args)
        {
            Console.Write("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Car Rental Reservation System ~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            Console.Write("\nName: Dhairya Bhavsar");
            Console.Write("\nStudent Number: 8960102");
            Console.Write("\nStudent I'D: Dbhavsar0102@conestogac.on.ca");
            Console.Write("\n-----------------------------------------------------------------------------------------");


            reservations.Add(new Reservation
            {
                CustomerId = "ABC123",
                Name = "John Doe",
                PhoneNumber = "123-456-7890",
                CustomerType = CustomerType.Premium,
                CarType = CarType.Economy,
                BasePrice = 29.99m,
                AdditionalServices = new Dictionary<string, decimal> { { "Child Car Seat", 14.99m } }
            });

            reservations.Add(new Reservation
            {
                CustomerId = "DEF456",
                Name = "Jane Smith",
                PhoneNumber = "234-567-8901",
                CustomerType = CustomerType.Regular,
                CarType = CarType.Standard,
                BasePrice = 49.99m,
                AdditionalServices = new Dictionary<string, decimal>()
            });

            reservations.Add(new Reservation
            {
                CustomerId = "GHI789",
                Name = "Alice Johnson",
                PhoneNumber = "345-678-9012",
                CustomerType = CustomerType.VIP,
                CarType = CarType.Luxury,
                BasePrice = 79.99m,
                AdditionalServices = new Dictionary<string, decimal> { { "GPS Navigation", 9.99m }, { "Chauffeur Service", 99.99m } }
            });
            bool exit = false;
            while (!exit)
            {
                Console.WriteLine("\nChoose an option below:");
                Console.WriteLine("1. Create a reservation");
                Console.WriteLine("2. List all reservations");
                Console.WriteLine("3. Clear all reservations");
                Console.WriteLine("4. Exit the program");
                Console.WriteLine("================================");
                Console.Write(">> ");

                string? choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        CreateReservation();
                        break;
                    case "2":
                        ListAllReservations();
                        break;
                    case "3":
                        ClearAllReservations();
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }

        static void CreateReservation()
        {
            Reservation reservation = new Reservation();

            Console.WriteLine("Enter customer information:");
            Console.Write("Customer ID: ");
            reservation.CustomerId = Console.ReadLine();
            Console.Write("Name: ");
            reservation.Name = Console.ReadLine();
            Console.Write("Phone Number: ");
            reservation.PhoneNumber = Console.ReadLine();
            Console.WriteLine("================================");
            Console.WriteLine("Customer Type (0 for Regular, 1 for Premium, 2 for VIP): ");
           
            if (!Enum.TryParse(Console.ReadLine(), out CustomerType customerType))
            {
                Console.WriteLine("Invalid customer type.");
                return;
            }
            reservation.CustomerType = customerType;

            Console.WriteLine("Choose the number corresponding to the car type the customer wants:");
            Console.WriteLine("0. Economy - $29.99/day");
            Console.WriteLine("1. Standard - $49.99/day");
            Console.WriteLine("2. Luxury - $79.99/day");
            Console.WriteLine("================================");
            Console.Write(">> ");
            if (!Enum.TryParse(Console.ReadLine(), out CarType carType))
            {
                Console.WriteLine("Invalid car type.");
                return;
            }
            reservation.CarType = carType;
            reservation.BasePrice = carType switch
            {
                CarType.Economy => 29.99m,
                CarType.Standard => 49.99m,
                CarType.Luxury => 79.99m,
                _ => 0,
            };

            reservation.AdditionalServices = new Dictionary<string, decimal>();
            Console.WriteLine("Does the customer want additional services?");
            Console.WriteLine("1. GPS Navigation - $9.99/day");
            Console.WriteLine("2. Child Car Seat - $14.99/day");
            Console.WriteLine("3. Chauffeur Service - $99.99/day");
            Console.WriteLine("Enter service number or 0 to finish:");
            Console.WriteLine("================================");
            while (true)
            {
                Console.Write(">> ");
                string? serviceChoice = Console.ReadLine();
                if (serviceChoice == "0")
                    break;
                switch (serviceChoice)
                {
                    case "1":
                        reservation.AdditionalServices.Add("GPS Navigation", 9.99m);
                        break;
                    case "2":
                        reservation.AdditionalServices.Add("Child Car Seat", 14.99m);
                        break;
                    case "3":
                        reservation.AdditionalServices.Add("Chauffeur Service", 99.99m);
                        break;
                    default:
                        Console.WriteLine("Invalid service choice.");
                        break;
                }
            }

            reservation.CalculateTotalPrice();
            reservations.Add(reservation);
            Console.WriteLine("Thank you! The reservation was successful.");
        }

        static void ListAllReservations()
        {
            foreach (var reservation in reservations)
            {
                reservation.PrintReservation();
                Console.WriteLine();
            }
        }

        static void ClearAllReservations()
        {
            reservations.Clear();
            Console.WriteLine("All reservations cleared.");
        }
    }
}