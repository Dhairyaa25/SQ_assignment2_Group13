﻿using CarRentalReservationSystem;

        class Reservation : Program
{
            public string? CustomerId { get; set; }
            public string? Name { get; set; }
            public string? PhoneNumber { get; set; }
            public CustomerType CustomerType { get; set; }
            public CarType CarType { get; set; }
            public decimal BasePrice { get; set; }
            public Dictionary<string, decimal>? AdditionalServices { get; set; }
            public decimal TotalPrice { get; set; }

            public void CalculateTotalPrice()
            {
                TotalPrice = BasePrice;
        #pragma warning disable CS8602 
                foreach (var service in AdditionalServices)
                {
                    TotalPrice += service.Value;
                }
        #pragma warning restore CS8602 
            }

            public void PrintReservation()
            {
        #pragma warning disable CS8602 
                Console.WriteLine($"Customer ID: {CustomerId.Substring(0, 3)}XXX");
        #pragma warning restore CS8602 
                Console.WriteLine($"Name: {Name}");
                Console.WriteLine($"Phone Number: {PhoneNumber}");
                Console.WriteLine($"Customer Type: {CustomerType}");
                Console.WriteLine($"Car Type: {CarType} - ${BasePrice}/day");

                Console.WriteLine("Additional Services:");
        #pragma warning disable CS8602 
                foreach (var service in AdditionalServices)
                {
                    Console.WriteLine($"{service.Key} - ${service.Value}/day");
                }
        #pragma warning restore CS8602 

                Console.WriteLine($"Total Price: ${TotalPrice}");
            }
        }
