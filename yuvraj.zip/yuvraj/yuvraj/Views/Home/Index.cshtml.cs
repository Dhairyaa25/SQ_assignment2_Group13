﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace yuvraj.Views.Home
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}